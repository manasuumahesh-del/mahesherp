import { PrismaClient, Weekday } from "@prisma/client";
import { hashPassword } from "../src/lib/passwords";
import { ensureEnrollments, ensureMarksClasses } from "../src/lib/enrollment";
import { TEST_NAMES } from "../src/lib/timeSlots";

const prisma = new PrismaClient();

async function main() {
  const defaultPassword = process.env.SEED_DEFAULT_PASSWORD || "Campus@123";
  const passwordHash = await hashPassword(defaultPassword);

  console.log("Seeding departments, courses, classes...");
  const cse = await prisma.department.upsert({
    where: { code: "CSE" },
    update: {},
    create: { code: "CSE", name: "Computer Science & Engineering" },
  });

  const ise = await prisma.department.upsert({
    where: { code: "ISE" },
    update: {},
    create: { code: "ISE", name: "Information Science & Engineering" },
  });

  const courseData = [
    { code: "CS701", name: "Internet of Things", shortName: "IoT", departmentId: cse.id },
    { code: "CS303", name: "Operating Systems", shortName: "OS", departmentId: cse.id },
    { code: "BME654A", name: "Project Management", shortName: "PM", departmentId: cse.id },
    { code: "CS307A", name: "Project Management with Git", shortName: "PMG", departmentId: cse.id },
  ];
  const courses = [];
  for (const c of courseData) {
    courses.push(await prisma.course.upsert({ where: { code: c.code }, update: {}, create: c }));
  }

  const classA = await prisma.class.upsert({
    where: { departmentId_section_semester: { departmentId: cse.id, section: "A", semester: 7 } },
    update: {},
    create: { departmentId: cse.id, section: "A", semester: 7 },
  });
  const classB = await prisma.class.upsert({
    where: { departmentId_section_semester: { departmentId: cse.id, section: "B", semester: 3 } },
    update: {},
    create: { departmentId: cse.id, section: "B", semester: 3 },
  });

  console.log("Seeding admin, teacher, student accounts...");

  // Admin
  const adminUser = await prisma.user.upsert({
    where: { username: "admin" },
    update: {},
    create: {
      username: "admin",
      passwordHash,
      name: "Admin",
      role: "ADMIN",
      mustChangePassword: true,
    },
  });

  // Teacher
  const teacherUser = await prisma.user.upsert({
    where: { username: "mahesha_t01" },
    update: {},
    create: {
      username: "mahesha_t01",
      passwordHash,
      name: "Mahesha",
      email: "mahesh.cse.nc@cambridge.edu.in",
      role: "TEACHER",
      mustChangePassword: true,
    },
  });
  const teacher = await prisma.teacher.upsert({
    where: { employeeId: "T01" },
    update: {},
    create: {
      employeeId: "T01",
      userId: teacherUser.id,
      departmentId: cse.id,
      sex: "MALE",
      dob: new Date("1985-01-01"),
    },
  });

  // Student
  const studentUser = await prisma.user.upsert({
    where: { username: "samarth_301" },
    update: {},
    create: {
      username: "samarth_301",
      passwordHash,
      name: "Samarth",
      role: "STUDENT",
      mustChangePassword: true,
    },
  });
  const student = await prisma.student.upsert({
    where: { usn: "1CG21CS301" },
    update: {},
    create: {
      usn: "1CG21CS301",
      userId: studentUser.id,
      classId: classA.id,
      sex: "MALE",
      dob: new Date("2003-05-10"),
    },
  });

  // A handful more students in class A so attendance/marks pages have real data.
  const extraNames = ["Anjali", "Deepak", "Farhan", "Keerthi", "Manoj", "Priya", "Ravi", "Sneha"];
  const students = [student];
  for (let i = 0; i < extraNames.length; i++) {
    const usn = `1CG21CS3${String(2 + i).padStart(2, "0")}`;
    const username = `${extraNames[i].toLowerCase()}_${usn.slice(-3)}`;
    const u = await prisma.user.upsert({
      where: { username },
      update: {},
      create: { username, passwordHash, name: extraNames[i], role: "STUDENT", mustChangePassword: true },
    });
    const s = await prisma.student.upsert({
      where: { usn },
      update: {},
      create: {
        usn,
        userId: u.id,
        classId: classA.id,
        sex: i % 2 === 0 ? "FEMALE" : "MALE",
        dob: new Date("2003-01-01"),
      },
    });
    students.push(s);
  }

  console.log("Seeding assignments, timetable slots...");
  const assignIoT = await prisma.assign.upsert({
    where: { classId_courseId_teacherId: { classId: classA.id, courseId: courses[0].id, teacherId: teacher.id } },
    update: {},
    create: { classId: classA.id, courseId: courses[0].id, teacherId: teacher.id },
  });
  const assignPM = await prisma.assign.upsert({
    where: { classId_courseId_teacherId: { classId: classA.id, courseId: courses[2].id, teacherId: teacher.id } },
    update: {},
    create: { classId: classA.id, courseId: courses[2].id, teacherId: teacher.id },
  });

  await ensureMarksClasses(assignIoT.id);
  await ensureMarksClasses(assignPM.id);
  await ensureEnrollments(classA.id, courses[0].id);
  await ensureEnrollments(classA.id, courses[2].id);

  await prisma.assignTime.upsert({
    where: { assignId_day_period: { assignId: assignIoT.id, day: Weekday.MONDAY, period: 0 } },
    update: {},
    create: { assignId: assignIoT.id, day: Weekday.MONDAY, period: 0 },
  });
  await prisma.assignTime.upsert({
    where: { assignId_day_period: { assignId: assignIoT.id, day: Weekday.WEDNESDAY, period: 2 } },
    update: {},
    create: { assignId: assignIoT.id, day: Weekday.WEDNESDAY, period: 2 },
  });
  await prisma.assignTime.upsert({
    where: { assignId_day_period: { assignId: assignPM.id, day: Weekday.TUESDAY, period: 1 } },
    update: {},
    create: { assignId: assignPM.id, day: Weekday.TUESDAY, period: 1 },
  });

  console.log("Seeding a few weeks of attendance history...");
  const today = new Date();
  for (let dayOffset = 21; dayOffset >= 0; dayOffset -= 1) {
    const date = new Date(today);
    date.setDate(date.getDate() - dayOffset);
    const weekday = date.getDay(); // 0 = Sunday
    if (weekday === 0) continue; // skip Sundays

    for (const assign of [assignIoT, assignPM]) {
      const session = await prisma.attendanceSession.upsert({
        where: { assignId_date: { assignId: assign.id, date } },
        update: {},
        create: { assignId: assign.id, date },
      });
      for (const s of students) {
        const present = Math.random() > 0.18; // ~82% attendance baseline
        await prisma.attendance.upsert({
          where: { sessionId_studentId: { sessionId: session.id, studentId: s.id } },
          update: {},
          create: { sessionId: session.id, studentId: s.id, status: present ? "PRESENT" : "ABSENT" },
        });
      }
    }
  }

  console.log("Seeding sample marks (Internal Test 1 published)...");
  for (const assign of [assignIoT, assignPM]) {
    for (const s of students) {
      const sc = await prisma.studentCourse.findUnique({
        where: { studentId_courseId: { studentId: s.id, courseId: assign.courseId } },
      });
      if (!sc) continue;
      const score = 10 + Math.floor(Math.random() * 10);
      await prisma.marks.update({
        where: { studentCourseId_test: { studentCourseId: sc.id, test: "INTERNAL_1" } },
        data: { score },
      });
    }
    await prisma.marksClass.update({
      where: { assignId_test: { assignId: assign.id, test: "INTERNAL_1" } },
      data: { published: true },
    });
  }

  console.log("\nSeed complete. Default login password for every account:", defaultPassword);
  console.log("  admin / " + defaultPassword);
  console.log("  mahesha_t01 / " + defaultPassword, "(teacher)");
  console.log("  samarth_301 / " + defaultPassword, "(student)");
  console.log("Everyone will be prompted to change their password on first login.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
