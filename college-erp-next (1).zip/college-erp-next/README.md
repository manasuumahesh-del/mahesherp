# College ERP (Next.js)

A rebuild of the original Django "College-ERP" project as a single Next.js app,
designed to deploy straight from GitHub to Vercel with a free Neon Postgres
database. Same core idea - attendance, marks, and timetable for students,
teachers and admins - with a modern UI, a few new features, and basic account
security that the original didn't have.

## What's different from the original

- **Per-account passwords.** The original gave every single account the same
  password (`project123`). Here, every new account gets its own randomly
  generated temporary password and is forced to set a new one on first login.
- **Role-based route protection** via middleware - a student can never load a
  teacher or admin URL, even by guessing it.
- **Hashed passwords** (bcrypt, 12 rounds) instead of plaintext-adjacent auth.
- **Dashboards with charts** (attendance trends, marks) for students, teachers
  and admins.
- **Excel export** of a class's marks/attendance, and a per-student **PDF
  report**.
- **CSV bulk import** for adding a whole class of students at once.
- **Email notifications** (optional) when marks are published or a student's
  attendance drops below 75%.
- Runs entirely on Vercel's serverless functions + a Postgres database -
  nothing to self-host.

## Tech stack

- **Next.js 14** (App Router, TypeScript) - one project, frontend + backend.
- **Prisma + PostgreSQL** (built for [Neon](https://neon.tech), Vercel's
  recommended serverless Postgres).
- **NextAuth.js** (Credentials provider, JWT sessions) for auth.
- **Tailwind CSS** for styling, **Recharts** for charts.
- **ExcelJS** / **pdf-lib** for exports, **Nodemailer** for email.

## 1. Run it locally

```bash
npm install
cp .env.example .env
# edit .env: paste in your Neon connection strings and a random NEXTAUTH_SECRET
npx prisma db push      # creates all tables from prisma/schema.prisma
npm run db:seed         # creates a demo admin/teacher/student + sample data
npm run dev
```

Open http://localhost:3000 and sign in. The seed script prints the demo
usernames and the shared default password it used - check your terminal
output. You'll be asked to set a new password immediately after logging in
(that's intentional).

Generate `NEXTAUTH_SECRET` with:

```bash
openssl rand -base64 32
```

## 2. Create a free Postgres database (Neon)

1. Go to https://console.neon.tech and sign up (free tier is enough).
2. Create a new project.
3. On the project dashboard, copy the **pooled** connection string into
   `DATABASE_URL`, and the **direct** connection string into `DIRECT_URL`
   (Neon labels these clearly on the "Connection Details" panel). Prisma
   needs both: the pooled one for normal queries, the direct one for
   migrations.
4. Make sure both include `?sslmode=require`.

Supabase or any other Postgres works too - just adjust the two connection
strings the same way (Supabase: use the "connection pooling" string for
`DATABASE_URL`).

## 3. Push this project to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/college-erp.git
git push -u origin main
```

## 4. Deploy to Vercel

1. Go to https://vercel.com/new and import the GitHub repo you just pushed.
2. Vercel auto-detects Next.js - leave the build settings as default.
3. Before clicking Deploy, open **Environment Variables** and add:
   - `DATABASE_URL` - your Neon pooled connection string
   - `DIRECT_URL` - your Neon direct connection string
   - `NEXTAUTH_SECRET` - the value you generated with `openssl rand -base64 32`
   - `NEXTAUTH_URL` - leave this out for now, or set it after your first
     deploy once you know your `*.vercel.app` URL (Vercel also sets this
     automatically for most setups)
   - `SEED_DEFAULT_PASSWORD` - optional, only used by the seed script
   - `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM` -
     optional, only needed if you want email notifications (see below)
4. Click **Deploy**.
5. Once deployed, run the database migration and seed against your Neon DB.
   The easiest way is from your own machine, pointed at the same `.env`
   values you put into Vercel:
   ```bash
   npx prisma db push
   npm run db:seed
   ```
6. Visit your `*.vercel.app` URL and log in with one of the seeded accounts.

Every time you push to `main`, Vercel redeploys automatically. If you change
`prisma/schema.prisma`, run `npx prisma db push` (or set up
`prisma migrate deploy` in a build step) against the same database before or
after deploying so the schema stays in sync.

## 5. Setting up real accounts

Once you're in as `admin`:

1. **Departments** → add your department(s).
2. **Courses** → add the subjects each department teaches.
3. **Classes** → add a class per department + semester + section
   (e.g. CSE, Sem 7, Section A).
4. **Teachers** → add teachers; each gets a generated username + temporary
   password shown once on screen - copy it and hand it to them.
5. **Students** → add students one at a time, or use **Bulk import (CSV)**
   with the provided template to add a whole class at once.
6. **Assign & timetable** → link a teacher to a course for a class, then add
   weekly timetable slots for it (this is what drives both the timetable
   pages and which classes a teacher sees for attendance/marks).

## 6. Email notifications (optional)

Notifications are sent via SMTP through Nodemailer, so they work with any
provider. Fill in the four `SMTP_*` environment variables and redeploy:

- **Gmail**: use an [App Password](https://myaccount.google.com/apppasswords)
  (not your normal Gmail password), `SMTP_HOST=smtp.gmail.com`, `SMTP_PORT=587`.
- **Outlook/Zoho/any provider**: use their SMTP host/port + your credentials.

If these are left blank, the app runs completely normally - it just silently
skips sending emails.

## Project structure

```
prisma/schema.prisma      Database schema (Postgres)
prisma/seed.ts            Demo data seeding script
src/lib/                  Auth, Prisma client, validation, email, business logic
src/middleware.ts         Role-based route protection + security headers
src/app/login             Sign-in page
src/app/change-password   Forced password change for new accounts
src/app/student/*         Student dashboard, attendance, marks, timetable
src/app/teacher/*         Teacher classes, attendance-taking, marks entry, reports
src/app/admin/*           Admin CRUD for departments/courses/classes/teachers/students,
                           CSV import, assignment + timetable scheduling
src/app/api/*             All backend routes (REST-ish, JSON in/out)
```

## Security notes (read this)

This is the "little security" tier - enough that you're not handing out one
shared password to your whole college, without needing a security audit:

- Passwords are hashed with bcrypt and never stored or logged in plain text.
- Every new account gets a unique, randomly generated temporary password and
  must change it before doing anything else.
- Sessions are signed JWTs (`NEXTAUTH_SECRET`), 8-hour expiry.
- Every page and API route re-checks the user's role server-side - the UI
  hiding a button is never the only thing stopping an action.
- Teachers can only ever touch classes explicitly assigned to them (checked
  on every request, not just in the UI).
- Basic security headers (`X-Frame-Options`, `X-Content-Type-Options`,
  `Referrer-Policy`) are set on every authenticated response.
- All form input is validated server-side with Zod before touching the
  database.

What this does **not** include (upgrade later if you need it): rate-limiting
on the login endpoint, CSRF tokens beyond NextAuth's built-in same-site
cookie protection, audit logging, or two-factor auth. For a small internal
college tool this is a reasonable line to draw, but say the word if you want
any of that added.
