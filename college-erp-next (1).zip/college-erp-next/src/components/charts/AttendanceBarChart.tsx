"use client";

import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export type AttendanceChartDatum = {
  name: string;
  percentage: number;
};

export default function AttendanceBarChart({ data }: { data: AttendanceChartDatum[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
        <XAxis dataKey="name" tick={{ fontSize: 12, fill: "#64748b" }} axisLine={false} tickLine={false} />
        <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: "#64748b" }} axisLine={false} tickLine={false} />
        <Tooltip
          cursor={{ fill: "#f1f5f9" }}
          formatter={(value: number) => [`${value}%`, "Attendance"]}
          contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0" }}
        />
        <Bar dataKey="percentage" radius={[8, 8, 0, 0]} maxBarSize={48}>
          {data.map((d, i) => (
            <Cell key={i} fill={d.percentage < 75 ? "#ef4444" : "#255ceb"} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
