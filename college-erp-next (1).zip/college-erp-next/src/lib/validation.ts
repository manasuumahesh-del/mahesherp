import { z } from "zod";

export const createDepartmentSchema = z.object({
  code: z.string().trim().min(2).max(20),
  name: z.string().trim().min(2).max(200),
});

export const createCourseSchema = z.object({
  code: z.string().trim().min(2).max(20),
  name: z.string().trim().min(2).max(200),
  shortName: z.string().trim().min(1).max(20),
  departmentId: z.string().min(1),
});

export const createClassSchema = z.object({
  section: z.string().trim().min(1).max(20),
  semester: z.coerce.number().int().min(1).max(8),
  departmentId: z.string().min(1),
});

export const createTeacherSchema = z.object({
  employeeId: z.string().trim().min(1).max(50),
  name: z.string().trim().min(2).max(200),
  departmentId: z.string().min(1),
  sex: z.enum(["MALE", "FEMALE", "OTHER"]),
  dob: z.coerce.date(),
  email: z.string().email().optional().or(z.literal("")),
});

export const createStudentSchema = z.object({
  usn: z.string().trim().min(2).max(50),
  name: z.string().trim().min(2).max(200),
  classId: z.string().min(1),
  sex: z.enum(["MALE", "FEMALE", "OTHER"]),
  dob: z.coerce.date(),
  email: z.string().email().optional().or(z.literal("")),
});

export const createAssignSchema = z.object({
  classId: z.string().min(1),
  courseId: z.string().min(1),
  teacherId: z.string().min(1),
});

export const createAssignTimeSchema = z.object({
  assignId: z.string().min(1),
  day: z.enum(["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"]),
  period: z.coerce.number().int().min(0).max(8),
});

export const takeAttendanceSchema = z.object({
  assignId: z.string().min(1),
  date: z.coerce.date(),
  isExtra: z.boolean().optional(),
  statuses: z.record(z.string(), z.enum(["PRESENT", "ABSENT"])),
});

export const enterMarksSchema = z.object({
  assignId: z.string().min(1),
  test: z.enum(["INTERNAL_1", "INTERNAL_2", "INTERNAL_3", "EVENT_1", "EVENT_2", "SEMESTER_END"]),
  scores: z.record(z.string(), z.coerce.number().int().min(0)),
});

export const changePasswordSchema = z
  .object({
    currentPassword: z.string().min(1),
    newPassword: z.string().min(8, "Password must be at least 8 characters"),
    confirmPassword: z.string().min(1),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

export const csvStudentRowSchema = z.object({
  usn: z.string().trim().min(2),
  name: z.string().trim().min(2),
  section: z.string().trim().min(1),
  semester: z.coerce.number().int().min(1).max(8),
  departmentCode: z.string().trim().min(1),
  sex: z
    .string()
    .optional()
    .transform((v) => (v || "MALE").trim().toUpperCase())
    .pipe(z.enum(["MALE", "FEMALE", "OTHER"])),
  dob: z.string().trim().min(4),
  email: z.string().email().optional().or(z.literal("")),
});
