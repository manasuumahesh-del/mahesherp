import { prisma } from "@/lib/prisma";

export type AttendanceSummary = {
  courseId: string;
  courseName: string;
  courseShortName: string;
  attended: number;
  total: number;
  percentage: number;
  classesToAttendFor75: number;
};

/** Computes per-course attendance percentage for a student, plus how many
 * consecutive classes they'd need to attend to climb back to 75%. */
export async function getStudentAttendanceSummary(studentId: string): Promise<AttendanceSummary[]> {
  const student = await prisma.student.findUniqueOrThrow({
    where: { id: studentId },
    select: { classId: true },
  });

  const assigns = await prisma.assign.findMany({
    where: { classId: student.classId },
    include: { course: true },
  });

  const summaries: AttendanceSummary[] = [];
  for (const assign of assigns) {
    const records = await prisma.attendance.findMany({
      where: { studentId, session: { assignId: assign.id, cancelled: false } },
      select: { status: true },
    });
    const total = records.length;
    const attended = records.filter((r) => r.status === "PRESENT").length;
    const percentage = total === 0 ? 0 : Math.round((attended / total) * 10000) / 100;

    let classesToAttendFor75 = 0;
    if (total > 0) {
      const needed = Math.ceil((0.75 * total - attended) / 0.25);
      classesToAttendFor75 = Math.max(0, needed);
    }

    summaries.push({
      courseId: assign.course.id,
      courseName: assign.course.name,
      courseShortName: assign.course.shortName,
      attended,
      total,
      percentage,
      classesToAttendFor75,
    });
  }
  return summaries;
}
