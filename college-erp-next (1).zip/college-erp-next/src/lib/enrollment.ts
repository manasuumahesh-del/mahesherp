import { prisma } from "@/lib/prisma";
import { TEST_NAMES, maxScoreFor } from "@/lib/timeSlots";

/**
 * Ensures a StudentCourse (+ its six Marks rows) exists for every
 * student in a class against a given course. Mirrors the Django
 * `post_save` signal from the original project, but called explicitly
 * from the places that used to rely on the signal firing:
 *   - a new Assign (teacher/course/class link) is created
 *   - a new Student is added to a class
 */
export async function ensureEnrollments(classId: string, courseId: string) {
  const students = await prisma.student.findMany({ where: { classId }, select: { id: true } });
  for (const student of students) {
    await ensureEnrollment(student.id, courseId);
  }
}

export async function ensureEnrollment(studentId: string, courseId: string) {
  const existing = await prisma.studentCourse.findUnique({
    where: { studentId_courseId: { studentId, courseId } },
  });
  if (existing) return existing;

  return prisma.studentCourse.create({
    data: {
      studentId,
      courseId,
      marks: {
        create: TEST_NAMES.map((test) => ({ test, score: 0, maxScore: maxScoreFor(test) })),
      },
    },
  });
}

/** Ensures a StudentCourse exists for a newly enrolled student against every course already assigned to their class. */
export async function ensureEnrollmentsForNewStudent(studentId: string, classId: string) {
  const assigns = await prisma.assign.findMany({ where: { classId }, select: { courseId: true } });
  const uniqueCourseIds = Array.from(new Set(assigns.map((a) => a.courseId)));
  for (const courseId of uniqueCourseIds) {
    await ensureEnrollment(studentId, courseId);
  }
}

/** Ensures a MarksClass tracking row exists for every test for a new Assign. */
export async function ensureMarksClasses(assignId: string) {
  for (const test of TEST_NAMES) {
    await prisma.marksClass.upsert({
      where: { assignId_test: { assignId, test } },
      update: {},
      create: { assignId, test },
    });
  }
}
