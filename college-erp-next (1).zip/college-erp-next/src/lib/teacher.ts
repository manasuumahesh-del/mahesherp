import { prisma } from "@/lib/prisma";
import { AuthError } from "@/lib/authz";

export async function getTeacherBySessionUserId(userId: string) {
  return prisma.teacher.findUniqueOrThrow({ where: { userId } });
}

/** Throws if the given assign doesn't belong to this teacher - guards every teacher route/API against ID tampering. */
export async function getOwnedAssign(assignId: string, teacherId: string) {
  const assign = await prisma.assign.findFirst({
    where: { id: assignId, teacherId },
    include: { course: true, class: { include: { department: true } } },
  });
  if (!assign) throw new AuthError("Class not found or not assigned to you", 404);
  return assign;
}
