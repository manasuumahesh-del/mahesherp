import nodemailer from "nodemailer";

let transporter: nodemailer.Transporter | null | undefined;

function getTransporter() {
  if (transporter !== undefined) return transporter;

  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD } = process.env;
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASSWORD) {
    transporter = null; // email disabled - no env vars configured
    return transporter;
  }

  transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT) || 587,
    secure: Number(SMTP_PORT) === 465,
    auth: { user: SMTP_USER, pass: SMTP_PASSWORD },
  });
  return transporter;
}

/**
 * Fire-and-forget email send. Notifications are a nice-to-have, not a
 * critical path - if SMTP isn't configured or the send fails, we log and
 * move on rather than breaking the calling request (marks entry, etc).
 */
export async function sendEmail(to: string | null | undefined, subject: string, html: string) {
  if (!to) return;
  const t = getTransporter();
  if (!t) return;

  try {
    await t.sendMail({
      from: process.env.SMTP_FROM || "College ERP <no-reply@example.com>",
      to,
      subject,
      html,
    });
  } catch (err) {
    console.error("[email] failed to send:", err);
  }
}

export function lowAttendanceEmail(studentName: string, courseName: string, pct: number) {
  return {
    subject: `Attendance alert: ${courseName}`,
    html: `<p>Hi ${studentName},</p>
      <p>Your attendance in <strong>${courseName}</strong> is currently <strong>${pct}%</strong>, which is below the 75% requirement.</p>
      <p>Please contact your course teacher if you think this is a mistake.</p>`,
  };
}

export function marksPublishedEmail(studentName: string, courseName: string, testLabel: string, score: number, max: number) {
  return {
    subject: `Marks published: ${courseName} - ${testLabel}`,
    html: `<p>Hi ${studentName},</p>
      <p>Your marks for <strong>${testLabel}</strong> in <strong>${courseName}</strong> have been published: <strong>${score} / ${max}</strong>.</p>`,
  };
}
