// Shared timetable constants. `period` stored on AssignTime is the index
// into this array. Kept out of the DB enum so admins could extend the day
// structure later without a migration.
export const TIME_SLOTS = [
  "7:30 - 8:30",
  "8:30 - 9:30",
  "9:30 - 10:30",
  "11:00 - 11:50",
  "11:50 - 12:40",
  "12:40 - 1:30",
  "2:30 - 3:30",
  "3:30 - 4:30",
  "4:30 - 5:30",
] as const;

export const WEEKDAYS = [
  "MONDAY",
  "TUESDAY",
  "WEDNESDAY",
  "THURSDAY",
  "FRIDAY",
  "SATURDAY",
] as const;

export const WEEKDAY_LABELS: Record<(typeof WEEKDAYS)[number], string> = {
  MONDAY: "Mon",
  TUESDAY: "Tue",
  WEDNESDAY: "Wed",
  THURSDAY: "Thu",
  FRIDAY: "Fri",
  SATURDAY: "Sat",
};

export const TEST_NAMES = [
  "INTERNAL_1",
  "INTERNAL_2",
  "INTERNAL_3",
  "EVENT_1",
  "EVENT_2",
  "SEMESTER_END",
] as const;

export const TEST_LABELS: Record<(typeof TEST_NAMES)[number], string> = {
  INTERNAL_1: "Internal Test 1",
  INTERNAL_2: "Internal Test 2",
  INTERNAL_3: "Internal Test 3",
  EVENT_1: "Event 1",
  EVENT_2: "Event 2",
  SEMESTER_END: "Semester End Exam",
};

export function maxScoreFor(test: string): number {
  return test === "SEMESTER_END" ? 100 : 20;
}

// CIE = sum of best-effort internal + event marks (first 5 tests, out of
// 20 each = 100), scaled down to a 40-mark continuous internal evaluation
// score, matching the original project's convention.
export function computeCie(scores: { test: string; score: number }[]): number {
  const relevant = scores.filter((s) => s.test !== "SEMESTER_END");
  const total = relevant.reduce((sum, s) => sum + s.score, 0);
  return Math.ceil(total / 2);
}
