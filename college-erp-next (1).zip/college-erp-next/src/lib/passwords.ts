import bcrypt from "bcryptjs";

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 12);
}

/**
 * Generates a username + a one-time default password for a newly created
 * account. Unlike the original project (which gave every single account
 * the same static password), each account gets its own random default
 * password, and `mustChangePassword` forces it to be changed on first
 * login - so a leaked seed list or a guessed username alone isn't enough.
 */
export function generateDefaultPassword(): string {
  const words = ["Orbit", "Maple", "Comet", "River", "Cedar", "Falcon", "Nova", "Delta"];
  const word = words[Math.floor(Math.random() * words.length)];
  const digits = Math.floor(1000 + Math.random() * 9000);
  const symbols = ["!", "@", "#", "$"];
  const symbol = symbols[Math.floor(Math.random() * symbols.length)];
  return `${word}${digits}${symbol}`;
}

export function slugUsername(fullName: string, suffix: string): string {
  const first = fullName.trim().split(/\s+/)[0]?.toLowerCase().replace(/[^a-z0-9]/g, "") || "user";
  return `${first}_${suffix.toLowerCase().replace(/[^a-z0-9]/g, "")}`;
}
