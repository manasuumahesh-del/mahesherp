import { PrismaClient } from "@prisma/client";

// Prevents exhausting the Postgres connection limit in dev (Next.js hot
// reload would otherwise create a brand new PrismaClient on every save).
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
