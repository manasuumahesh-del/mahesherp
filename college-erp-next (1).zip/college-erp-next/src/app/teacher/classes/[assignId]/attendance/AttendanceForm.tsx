"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import clsx from "clsx";

type StudentRow = {
  id: string;
  usn: string;
  name: string;
  initialStatus: "PRESENT" | "ABSENT";
};

export default function AttendanceForm({
  assignId,
  date,
  students,
}: {
  assignId: string;
  date: string;
  students: StudentRow[];
}) {
  const router = useRouter();
  const [statuses, setStatuses] = useState<Record<string, "PRESENT" | "ABSENT">>(
    Object.fromEntries(students.map((s) => [s.id, s.initialStatus]))
  );
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  function toggle(id: string, status: "PRESENT" | "ABSENT") {
    setStatuses((prev) => ({ ...prev, [id]: status }));
  }

  function markAll(status: "PRESENT" | "ABSENT") {
    setStatuses(Object.fromEntries(students.map((s) => [s.id, status])));
  }

  async function handleSubmit() {
    setSaving(true);
    setMessage(null);
    const res = await fetch("/api/teacher/attendance", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ assignId, date, statuses }),
    });
    setSaving(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setMessage(data.error || "Could not save attendance.");
      return;
    }
    setMessage("Attendance saved.");
    router.refresh();
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold text-slate-900">Mark attendance</h2>
        <div className="flex gap-2">
          <button className="btn-secondary" onClick={() => markAll("PRESENT")} type="button">
            Mark all present
          </button>
          <button className="btn-secondary" onClick={() => markAll("ABSENT")} type="button">
            Mark all absent
          </button>
        </div>
      </div>

      <table className="table-clean">
        <thead>
          <tr>
            <th>USN</th>
            <th>Name</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {students.map((s) => (
            <tr key={s.id}>
              <td>{s.usn}</td>
              <td className="font-medium text-slate-800">{s.name}</td>
              <td>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => toggle(s.id, "PRESENT")}
                    className={clsx(
                      "px-3 py-1 rounded-lg text-xs font-medium",
                      statuses[s.id] === "PRESENT" ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-600"
                    )}
                  >
                    Present
                  </button>
                  <button
                    type="button"
                    onClick={() => toggle(s.id, "ABSENT")}
                    className={clsx(
                      "px-3 py-1 rounded-lg text-xs font-medium",
                      statuses[s.id] === "ABSENT" ? "bg-red-600 text-white" : "bg-slate-100 text-slate-600"
                    )}
                  >
                    Absent
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-4 flex items-center gap-3">
        <button className="btn-primary" onClick={handleSubmit} disabled={saving}>
          {saving ? "Saving..." : "Save attendance"}
        </button>
        {message && <span className="text-sm text-slate-600">{message}</span>}
      </div>
    </div>
  );
}
