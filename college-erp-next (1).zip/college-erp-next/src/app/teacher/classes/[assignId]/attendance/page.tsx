import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getTeacherBySessionUserId, getOwnedAssign } from "@/lib/teacher";
import AttendanceForm from "./AttendanceForm";
import Link from "next/link";
import { ChevronLeft } from "lucide-react";

export const dynamic = "force-dynamic";

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

export default async function TakeAttendancePage({
  params,
  searchParams,
}: {
  params: { assignId: string };
  searchParams: { date?: string };
}) {
  const session = await getServerSession(authOptions);
  const teacher = await getTeacherBySessionUserId(session!.user.id);
  const assign = await getOwnedAssign(params.assignId, teacher.id);
  const date = searchParams.date || todayIso();

  const students = await prisma.student.findMany({
    where: { classId: assign.classId },
    include: { user: true },
    orderBy: { usn: "asc" },
  });

  const existingSession = await prisma.attendanceSession.findUnique({
    where: { assignId_date: { assignId: assign.id, date: new Date(date) } },
    include: { records: true },
  });

  const rows = students.map((s) => {
    const record = existingSession?.records.find((r) => r.studentId === s.id);
    return {
      id: s.id,
      usn: s.usn,
      name: s.user.name,
      initialStatus: (record?.status ?? "PRESENT") as "PRESENT" | "ABSENT",
    };
  });

  return (
    <div className="space-y-6">
      <Link href="/teacher" className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700">
        <ChevronLeft size={16} /> Back to classes
      </Link>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">
            {assign.course.name} - {assign.class.department.code} Sem {assign.class.semester} {assign.class.section}
          </h1>
          <p className="text-sm text-slate-500">Take or edit attendance for a specific date.</p>
        </div>
        <form className="flex items-center gap-2">
          <input type="date" name="date" defaultValue={date} className="input" />
          <button className="btn-secondary" type="submit">
            Load
          </button>
        </form>
      </div>

      <AttendanceForm assignId={assign.id} date={date} students={rows} />
    </div>
  );
}
