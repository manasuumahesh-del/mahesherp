import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getTeacherBySessionUserId, getOwnedAssign } from "@/lib/teacher";
import { ensureEnrollment } from "@/lib/enrollment";
import { TEST_LABELS, maxScoreFor } from "@/lib/timeSlots";
import MarksEntryForm from "./MarksEntryForm";
import Link from "next/link";
import { ChevronLeft } from "lucide-react";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function MarksEntryPage({ params }: { params: { assignId: string; test: string } }) {
  const session = await getServerSession(authOptions);
  const teacher = await getTeacherBySessionUserId(session!.user.id);
  const assign = await getOwnedAssign(params.assignId, teacher.id);

  const test = params.test as keyof typeof TEST_LABELS;
  if (!TEST_LABELS[test]) notFound();

  const students = await prisma.student.findMany({
    where: { classId: assign.classId },
    include: { user: true },
    orderBy: { usn: "asc" },
  });

  const rows = [];
  for (const s of students) {
    const sc = await ensureEnrollment(s.id, assign.courseId);
    const mark = await prisma.marks.findUnique({
      where: { studentCourseId_test: { studentCourseId: sc.id, test } },
    });
    rows.push({ id: s.id, usn: s.usn, name: s.user.name, score: mark?.score ?? 0 });
  }

  return (
    <div className="space-y-6">
      <Link
        href={`/teacher/classes/${assign.id}/marks`}
        className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700"
      >
        <ChevronLeft size={16} /> Back to assessments
      </Link>
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">
          {TEST_LABELS[test]} - {assign.course.name}
        </h1>
        <p className="text-sm text-slate-500">
          {assign.class.department.code} Sem {assign.class.semester} {assign.class.section}
        </p>
      </div>

      <MarksEntryForm assignId={assign.id} test={test} maxScore={maxScoreFor(test)} students={rows} />
    </div>
  );
}
