import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getTeacherBySessionUserId, getOwnedAssign } from "@/lib/teacher";
import { TEST_NAMES, TEST_LABELS, maxScoreFor } from "@/lib/timeSlots";
import Link from "next/link";
import { ChevronLeft, ChevronRight, Download } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function MarksListPage({ params }: { params: { assignId: string } }) {
  const session = await getServerSession(authOptions);
  const teacher = await getTeacherBySessionUserId(session!.user.id);
  const assign = await getOwnedAssign(params.assignId, teacher.id);

  const marksClasses = await prisma.marksClass.findMany({ where: { assignId: assign.id } });
  const byTest = new Map(marksClasses.map((m) => [m.test, m]));

  return (
    <div className="space-y-6">
      <Link href="/teacher" className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700">
        <ChevronLeft size={16} /> Back to classes
      </Link>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">
            {assign.course.name} - {assign.class.department.code} Sem {assign.class.semester} {assign.class.section}
          </h1>
          <p className="text-sm text-slate-500">Enter or edit marks for each assessment.</p>
        </div>
        <a href={`/api/export/marks?assignId=${assign.id}`} className="btn-secondary">
          <Download size={16} /> Export class marks
        </a>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {TEST_NAMES.map((test) => {
          const mc = byTest.get(test);
          return (
            <Link
              key={test}
              href={`/teacher/classes/${assign.id}/marks/${test}`}
              className="card flex items-center justify-between hover:border-brand-300 transition-colors"
            >
              <div>
                <p className="font-medium text-slate-900">{TEST_LABELS[test]}</p>
                <p className="text-xs text-slate-500">Out of {maxScoreFor(test)}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className={`badge ${mc?.published ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`}>
                  {mc?.published ? "Published" : "Not entered"}
                </span>
                <ChevronRight size={16} className="text-slate-400" />
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
