"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type StudentRow = {
  id: string;
  usn: string;
  name: string;
  score: number;
};

export default function MarksEntryForm({
  assignId,
  test,
  maxScore,
  students,
}: {
  assignId: string;
  test: string;
  maxScore: number;
  students: StudentRow[];
}) {
  const router = useRouter();
  const [scores, setScores] = useState<Record<string, number>>(Object.fromEntries(students.map((s) => [s.id, s.score])));
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  function setScore(id: string, value: string) {
    const num = Math.max(0, Math.min(maxScore, Number(value) || 0));
    setScores((prev) => ({ ...prev, [id]: num }));
  }

  async function handleSubmit() {
    setSaving(true);
    setMessage(null);
    const res = await fetch("/api/teacher/marks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ assignId, test, scores }),
    });
    setSaving(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setMessage(data.error || "Could not save marks.");
      return;
    }
    setMessage("Marks published.");
    router.refresh();
  }

  return (
    <div className="card">
      <table className="table-clean">
        <thead>
          <tr>
            <th>USN</th>
            <th>Name</th>
            <th>Score (out of {maxScore})</th>
          </tr>
        </thead>
        <tbody>
          {students.map((s) => (
            <tr key={s.id}>
              <td>{s.usn}</td>
              <td className="font-medium text-slate-800">{s.name}</td>
              <td>
                <input
                  type="number"
                  min={0}
                  max={maxScore}
                  className="input w-24"
                  value={scores[s.id]}
                  onChange={(e) => setScore(s.id, e.target.value)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-4 flex items-center gap-3">
        <button className="btn-primary" onClick={handleSubmit} disabled={saving}>
          {saving ? "Saving..." : "Save & publish marks"}
        </button>
        {message && <span className="text-sm text-slate-600">{message}</span>}
      </div>
    </div>
  );
}
