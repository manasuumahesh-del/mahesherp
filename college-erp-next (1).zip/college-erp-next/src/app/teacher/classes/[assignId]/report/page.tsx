import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getTeacherBySessionUserId, getOwnedAssign } from "@/lib/teacher";
import { computeCie } from "@/lib/timeSlots";
import { ensureEnrollment } from "@/lib/enrollment";
import Link from "next/link";
import { ChevronLeft, Download, FileSpreadsheet } from "lucide-react";
import clsx from "clsx";

export const dynamic = "force-dynamic";

export default async function ClassReportPage({ params }: { params: { assignId: string } }) {
  const session = await getServerSession(authOptions);
  const teacher = await getTeacherBySessionUserId(session!.user.id);
  const assign = await getOwnedAssign(params.assignId, teacher.id);

  const students = await prisma.student.findMany({
    where: { classId: assign.classId },
    include: { user: true },
    orderBy: { usn: "asc" },
  });

  const rows = [];
  for (const s of students) {
    const sc = await ensureEnrollment(s.id, assign.courseId);
    const marks = await prisma.marks.findMany({ where: { studentCourseId: sc.id } });
    const attRecords = await prisma.attendance.findMany({
      where: { studentId: s.id, session: { assignId: assign.id, cancelled: false } },
    });
    const total = attRecords.length;
    const attended = attRecords.filter((r) => r.status === "PRESENT").length;
    const pct = total === 0 ? 0 : Math.round((attended / total) * 10000) / 100;

    rows.push({
      id: s.id,
      usn: s.usn,
      name: s.user.name,
      cie: computeCie(marks),
      attendancePct: pct,
    });
  }

  return (
    <div className="space-y-6">
      <Link
        href="/teacher"
        className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700"
      >
        <ChevronLeft size={16} /> Back to classes
      </Link>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">
            Class report - {assign.course.name}
          </h1>
          <p className="text-sm text-slate-500">
            {assign.class.department.code} Sem {assign.class.semester} {assign.class.section}
          </p>
        </div>
        <div className="flex gap-2">
          <a href={`/api/export/marks?assignId=${assign.id}`} className="btn-secondary">
            <FileSpreadsheet size={16} /> Marks (.xlsx)
          </a>
          <a href={`/api/export/attendance?assignId=${assign.id}`} className="btn-secondary">
            <Download size={16} /> Attendance (.xlsx)
          </a>
        </div>
      </div>

      <div className="card overflow-x-auto">
        <table className="table-clean">
          <thead>
            <tr>
              <th>USN</th>
              <th>Name</th>
              <th>CIE (out of 40)</th>
              <th>Attendance</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.usn}>
                <td>{r.usn}</td>
                <td className="font-medium text-slate-800">{r.name}</td>
                <td>{r.cie}</td>
                <td>
                  <span
                    className={clsx(
                      "badge",
                      r.attendancePct >= 75 ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"
                    )}
                  >
                    {r.attendancePct}%
                  </span>
                </td>
                <td>
                  <a
                    href={`/api/export/student-report?assignId=${assign.id}&studentId=${r.id}`}
                    className="text-xs text-brand-600 hover:underline"
                  >
                    PDF report
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
