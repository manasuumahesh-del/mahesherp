import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getTeacherBySessionUserId } from "@/lib/teacher";
import { TIME_SLOTS, WEEKDAYS, WEEKDAY_LABELS } from "@/lib/timeSlots";

export const dynamic = "force-dynamic";

export default async function TeacherTimetablePage() {
  const session = await getServerSession(authOptions);
  const teacher = await getTeacherBySessionUserId(session!.user.id);

  const slots = await prisma.assignTime.findMany({
    where: { assign: { teacherId: teacher.id } },
    include: { assign: { include: { course: true, class: true } } },
  });

  const lookup = new Map<string, string>();
  for (const s of slots) {
    lookup.set(`${s.day}-${s.period}`, `${s.assign.course.shortName} (${s.assign.class.section})`);
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">My timetable</h1>
        <p className="text-sm text-slate-500">Your weekly teaching schedule across all classes.</p>
      </div>

      <div className="card overflow-x-auto">
        <table className="table-clean">
          <thead>
            <tr>
              <th>Day</th>
              {TIME_SLOTS.map((slot, i) => (
                <th key={i}>{slot}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {WEEKDAYS.map((day) => (
              <tr key={day}>
                <td className="font-medium text-slate-800">{WEEKDAY_LABELS[day]}</td>
                {TIME_SLOTS.map((_, period) => {
                  const label = lookup.get(`${day}-${period}`);
                  return (
                    <td key={period}>
                      {label ? (
                        <span className="badge bg-brand-50 text-brand-700">{label}</span>
                      ) : (
                        <span className="text-slate-300">-</span>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
