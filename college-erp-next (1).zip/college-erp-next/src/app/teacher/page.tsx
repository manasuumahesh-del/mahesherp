import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getTeacherBySessionUserId } from "@/lib/teacher";
import Link from "next/link";
import { CalendarCheck, NotebookPen, FileText, Users } from "lucide-react";
import StatCard from "@/components/StatCard";

export const dynamic = "force-dynamic";

export default async function TeacherHomePage() {
  const session = await getServerSession(authOptions);
  const teacherBase = await getTeacherBySessionUserId(session!.user.id);
  const teacher = await prisma.teacher.findUniqueOrThrow({
    where: { id: teacherBase.id },
    include: { department: true },
  });

  const assigns = await prisma.assign.findMany({
    where: { teacherId: teacher.id },
    include: {
      course: true,
      class: { include: { department: true, _count: { select: { students: true } } } },
    },
  });

  const totalStudents = assigns.reduce((sum, a) => sum + a.class._count.students, 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Welcome, {session!.user.name}</h1>
        <p className="text-sm text-slate-500">Your assigned classes and quick actions.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard label="Classes assigned" value={assigns.length} icon={NotebookPen} />
        <StatCard label="Total students taught" value={totalStudents} icon={Users} />
        <StatCard label="Department" value={teacher.department.code} icon={FileText} hint={teacher.department.name} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {assigns.map((a) => (
          <div key={a.id} className="card">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="font-semibold text-slate-900">{a.course.name}</h2>
                <p className="text-sm text-slate-500">
                  {a.class.department.code} - Sem {a.class.semester} {a.class.section} - {a.class._count.students} students
                </p>
              </div>
              <span className="badge bg-brand-50 text-brand-700">{a.course.shortName}</span>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Link href={`/teacher/classes/${a.id}/attendance`} className="btn-secondary">
                <CalendarCheck size={15} /> Attendance
              </Link>
              <Link href={`/teacher/classes/${a.id}/marks`} className="btn-secondary">
                <NotebookPen size={15} /> Marks
              </Link>
              <Link href={`/teacher/classes/${a.id}/report`} className="btn-secondary">
                <FileText size={15} /> Report
              </Link>
            </div>
          </div>
        ))}
        {assigns.length === 0 && (
          <p className="text-sm text-slate-500">No classes assigned yet. Contact your admin.</p>
        )}
      </div>
    </div>
  );
}
