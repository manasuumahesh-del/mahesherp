import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import AppShell from "@/components/AppShell";
import { LayoutDashboard, CalendarClock } from "lucide-react";

const navItems = [
  { href: "/teacher", label: "My classes", icon: LayoutDashboard },
  { href: "/teacher/timetable", label: "Timetable", icon: CalendarClock },
];

export default async function TeacherLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);

  return (
    <AppShell navItems={navItems} roleLabel="Teacher" userName={session?.user.name || ""}>
      {children}
    </AppShell>
  );
}
