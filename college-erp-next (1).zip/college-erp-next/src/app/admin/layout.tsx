import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import AppShell from "@/components/AppShell";
import { LayoutDashboard, Building2, BookOpen, School, Users, Presentation, Link2 } from "lucide-react";

const navItems = [
  { href: "/admin", label: "Overview", icon: LayoutDashboard },
  { href: "/admin/departments", label: "Departments", icon: Building2 },
  { href: "/admin/courses", label: "Courses", icon: BookOpen },
  { href: "/admin/classes", label: "Classes", icon: School },
  { href: "/admin/teachers", label: "Teachers", icon: Presentation },
  { href: "/admin/students", label: "Students", icon: Users },
  { href: "/admin/assign", label: "Assign & timetable", icon: Link2 },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);

  return (
    <AppShell navItems={navItems} roleLabel="Admin" userName={session?.user.name || ""}>
      {children}
    </AppShell>
  );
}
