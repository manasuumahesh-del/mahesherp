import { prisma } from "@/lib/prisma";
import NewStudentForm from "./NewStudentForm";
import CsvImportForm from "./CsvImportForm";

export const dynamic = "force-dynamic";

export default async function StudentsPage() {
  const [students, classes] = await Promise.all([
    prisma.student.findMany({
      include: { user: true, class: { include: { department: true } } },
      orderBy: { usn: "asc" },
      take: 200,
    }),
    prisma.class.findMany({ include: { department: true }, orderBy: { semester: "asc" } }),
  ]);

  const classOptions = classes.map((c) => ({
    id: c.id,
    label: `${c.department.code} Sem ${c.semester} ${c.section}`,
  }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Students</h1>
        <p className="text-sm text-slate-500">Add students individually or import a whole class from a spreadsheet.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="card overflow-x-auto">
            <table className="table-clean">
              <thead>
                <tr>
                  <th>USN</th>
                  <th>Name</th>
                  <th>Class</th>
                  <th>Username</th>
                </tr>
              </thead>
              <tbody>
                {students.map((s) => (
                  <tr key={s.id}>
                    <td className="font-medium text-slate-800">{s.usn}</td>
                    <td>{s.user.name}</td>
                    <td>
                      {s.class.department.code} Sem {s.class.semester} {s.class.section}
                    </td>
                    <td className="font-mono text-xs">{s.user.username}</td>
                  </tr>
                ))}
                {students.length === 0 && (
                  <tr>
                    <td colSpan={4} className="text-center text-slate-400 py-6">
                      No students yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <CsvImportForm />
        </div>
        {classOptions.length > 0 ? (
          <NewStudentForm classes={classOptions} />
        ) : (
          <div className="card text-sm text-slate-500">Add a class first.</div>
        )}
      </div>
    </div>
  );
}
