"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { UploadCloud, FileDown } from "lucide-react";

type RowResult = { row: number; usn?: string; status: "created" | "skipped" | "error"; message?: string };

export default function CsvImportForm() {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [summary, setSummary] = useState<{ total: number; created: number; skipped: number; errors: number } | null>(null);
  const [results, setResults] = useState<RowResult[]>([]);

  async function handleFile(file: File) {
    setUploading(true);
    setError(null);
    setSummary(null);
    setResults([]);
    const form = new FormData();
    form.append("file", file);
    const res = await fetch("/api/admin/students/import", { method: "POST", body: form });
    const data = await res.json().catch(() => ({}));
    setUploading(false);
    if (!res.ok) {
      setError(data.error || "Import failed.");
      return;
    }
    setSummary(data.summary);
    setResults(data.results || []);
    router.refresh();
  }

  return (
    <div className="card space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-semibold text-slate-900">Bulk import students (CSV)</h2>
        <a href="/templates/students-template.csv" download className="btn-secondary text-xs">
          <FileDown size={14} /> Download template
        </a>
      </div>
      <p className="text-xs text-slate-500">
        Columns: <code>usn, name, section, semester, departmentCode, sex, dob, email</code>. The class (department + semester +
        section) must already exist. Each row gets its own auto-generated password.
      </p>

      <label className="flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-300 py-8 cursor-pointer hover:border-brand-400 transition-colors">
        <UploadCloud className="text-slate-400" size={28} />
        <span className="text-sm text-slate-500">{uploading ? "Uploading..." : "Click to choose a CSV file"}</span>
        <input
          ref={inputRef}
          type="file"
          accept=".csv,text/csv"
          className="hidden"
          disabled={uploading}
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleFile(file);
            e.target.value = "";
          }}
        />
      </label>

      {error && <p className="text-sm text-red-600">{error}</p>}

      {summary && (
        <div className="grid grid-cols-4 gap-2 text-center text-sm">
          <div className="rounded-lg bg-slate-50 py-2">
            <p className="font-semibold">{summary.total}</p>
            <p className="text-xs text-slate-500">Rows</p>
          </div>
          <div className="rounded-lg bg-emerald-50 py-2">
            <p className="font-semibold text-emerald-700">{summary.created}</p>
            <p className="text-xs text-emerald-600">Created</p>
          </div>
          <div className="rounded-lg bg-amber-50 py-2">
            <p className="font-semibold text-amber-700">{summary.skipped}</p>
            <p className="text-xs text-amber-600">Skipped</p>
          </div>
          <div className="rounded-lg bg-red-50 py-2">
            <p className="font-semibold text-red-700">{summary.errors}</p>
            <p className="text-xs text-red-600">Errors</p>
          </div>
        </div>
      )}

      {results.filter((r) => r.status !== "created").length > 0 && (
        <div className="max-h-48 overflow-y-auto text-xs space-y-1">
          {results
            .filter((r) => r.status !== "created")
            .map((r, i) => (
              <p key={i} className={r.status === "error" ? "text-red-600" : "text-amber-600"}>
                Row {r.row} ({r.usn || "?"}): {r.message}
              </p>
            ))}
        </div>
      )}
    </div>
  );
}
