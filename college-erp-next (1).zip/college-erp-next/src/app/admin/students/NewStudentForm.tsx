"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Plus } from "lucide-react";

export default function NewStudentForm({
  classes,
}: {
  classes: { id: string; label: string }[];
}) {
  const router = useRouter();
  const [usn, setUsn] = useState("");
  const [name, setName] = useState("");
  const [classId, setClassId] = useState(classes[0]?.id ?? "");
  const [sex, setSex] = useState("MALE");
  const [dob, setDob] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [credentials, setCredentials] = useState<{ username: string; password: string } | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setCredentials(null);
    const res = await fetch("/api/admin/students", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ usn, name, classId, sex, dob, email }),
    });
    const data = await res.json().catch(() => ({}));
    setSaving(false);
    if (!res.ok) {
      setError(data.error || "Could not create student.");
      return;
    }
    setCredentials(data.credentials);
    setUsn("");
    setName("");
    setDob("");
    setEmail("");
    router.refresh();
  }

  return (
    <div className="card space-y-3">
      <h2 className="font-semibold text-slate-900">Add student</h2>
      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <label className="label">USN</label>
          <input className="input" value={usn} onChange={(e) => setUsn(e.target.value)} required />
        </div>
        <div>
          <label className="label">Full name</label>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div>
          <label className="label">Class</label>
          <select className="input" value={classId} onChange={(e) => setClassId(e.target.value)} required>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.label}
              </option>
            ))}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Sex</label>
            <select className="input" value={sex} onChange={(e) => setSex(e.target.value)}>
              <option value="MALE">Male</option>
              <option value="FEMALE">Female</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
          <div>
            <label className="label">Date of birth</label>
            <input type="date" className="input" value={dob} onChange={(e) => setDob(e.target.value)} required />
          </div>
        </div>
        <div>
          <label className="label">Email (optional, for notifications)</label>
          <input type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button className="btn-primary" disabled={saving} type="submit">
          <Plus size={16} /> {saving ? "Adding..." : "Add student"}
        </button>
      </form>

      {credentials && (
        <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-sm text-emerald-800">
          <p className="font-medium mb-1">Account created - share these once:</p>
          <p>
            Username: <code className="font-mono">{credentials.username}</code>
          </p>
          <p>
            Temporary password: <code className="font-mono">{credentials.password}</code>
          </p>
        </div>
      )}
    </div>
  );
}
