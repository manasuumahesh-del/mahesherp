import { prisma } from "@/lib/prisma";
import NewAssignForm from "./NewAssignForm";
import AssignTimeRow from "./AssignTimeRow";

export const dynamic = "force-dynamic";

export default async function AssignPage() {
  const [classes, courses, teachers, assigns] = await Promise.all([
    prisma.class.findMany({ include: { department: true }, orderBy: { semester: "asc" } }),
    prisma.course.findMany({ include: { department: true }, orderBy: { code: "asc" } }),
    prisma.teacher.findMany({ include: { user: true }, orderBy: { employeeId: "asc" } }),
    prisma.assign.findMany({
      include: { course: true, teacher: { include: { user: true } }, class: { include: { department: true } }, assignTimes: true },
      orderBy: { id: "asc" },
    }),
  ]);

  const classOptions = classes.map((c) => ({ id: c.id, label: `${c.department.code} Sem ${c.semester} ${c.section}` }));
  const courseOptions = courses.map((c) => ({ id: c.id, label: `${c.code} - ${c.name}` }));
  const teacherOptions = teachers.map((t) => ({ id: t.id, label: `${t.user.name} (${t.employeeId})` }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Assign & timetable</h1>
        <p className="text-sm text-slate-500">Link a teacher to a course for a class, then schedule its weekly slots.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          {assigns.map((a) => (
            <AssignTimeRow
              key={a.id}
              assignId={a.id}
              courseLabel={a.course.name}
              classLabel={`${a.class.department.code} Sem ${a.class.semester} ${a.class.section}`}
              teacherLabel={a.teacher.user.name}
              slots={a.assignTimes.map((t) => ({ day: t.day, period: t.period }))}
            />
          ))}
          {assigns.length === 0 && <p className="text-sm text-slate-500">No assignments yet.</p>}
        </div>
        {classOptions.length > 0 && courseOptions.length > 0 && teacherOptions.length > 0 ? (
          <NewAssignForm classes={classOptions} courses={courseOptions} teachers={teacherOptions} />
        ) : (
          <div className="card text-sm text-slate-500">Add a department, course, class and teacher first.</div>
        )}
      </div>
    </div>
  );
}
