"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { TIME_SLOTS, WEEKDAYS, WEEKDAY_LABELS } from "@/lib/timeSlots";
import { Plus } from "lucide-react";

export default function AssignTimeRow({
  assignId,
  courseLabel,
  classLabel,
  teacherLabel,
  slots,
}: {
  assignId: string;
  courseLabel: string;
  classLabel: string;
  teacherLabel: string;
  slots: { day: string; period: number }[];
}) {
  const router = useRouter();
  const [day, setDay] = useState<string>(WEEKDAYS[0]);
  const [period, setPeriod] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function addSlot() {
    setSaving(true);
    setError(null);
    const res = await fetch("/api/admin/assign-time", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ assignId, day, period }),
    });
    setSaving(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Could not add slot.");
      return;
    }
    router.refresh();
  }

  return (
    <div className="border border-slate-200 rounded-xl p-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <p className="font-medium text-slate-900">{courseLabel}</p>
          <p className="text-xs text-slate-500">
            {classLabel} - {teacherLabel}
          </p>
        </div>
        <div className="flex flex-wrap gap-1">
          {slots.map((s, i) => (
            <span key={i} className="badge bg-brand-50 text-brand-700">
              {WEEKDAY_LABELS[s.day as keyof typeof WEEKDAY_LABELS]} {TIME_SLOTS[s.period]}
            </span>
          ))}
          {slots.length === 0 && <span className="text-xs text-slate-400">No slots scheduled</span>}
        </div>
      </div>

      <div className="flex items-center gap-2 mt-3">
        <select className="input" value={day} onChange={(e) => setDay(e.target.value)}>
          {WEEKDAYS.map((d) => (
            <option key={d} value={d}>
              {WEEKDAY_LABELS[d]}
            </option>
          ))}
        </select>
        <select className="input" value={period} onChange={(e) => setPeriod(Number(e.target.value))}>
          {TIME_SLOTS.map((slot, i) => (
            <option key={i} value={i}>
              {slot}
            </option>
          ))}
        </select>
        <button className="btn-secondary shrink-0" onClick={addSlot} disabled={saving} type="button">
          <Plus size={15} /> Add
        </button>
      </div>
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
    </div>
  );
}
