"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Plus } from "lucide-react";

export default function NewDepartmentForm() {
  const router = useRouter();
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const res = await fetch("/api/admin/departments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, name }),
    });
    setSaving(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Could not create department.");
      return;
    }
    setCode("");
    setName("");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="card space-y-3">
      <h2 className="font-semibold text-slate-900">Add department</h2>
      <div>
        <label className="label">Code</label>
        <input className="input" placeholder="CSE" value={code} onChange={(e) => setCode(e.target.value)} required />
      </div>
      <div>
        <label className="label">Name</label>
        <input
          className="input"
          placeholder="Computer Science & Engineering"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <button className="btn-primary" disabled={saving} type="submit">
        <Plus size={16} /> {saving ? "Adding..." : "Add department"}
      </button>
    </form>
  );
}
