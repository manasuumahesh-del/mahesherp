import { prisma } from "@/lib/prisma";
import NewDepartmentForm from "./NewDepartmentForm";

export const dynamic = "force-dynamic";

export default async function DepartmentsPage() {
  const departments = await prisma.department.findMany({
    include: { _count: { select: { courses: true, classes: true, teachers: true } } },
    orderBy: { code: "asc" },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Departments</h1>
        <p className="text-sm text-slate-500">Top-level academic departments.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card overflow-x-auto">
          <table className="table-clean">
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Courses</th>
                <th>Classes</th>
                <th>Teachers</th>
              </tr>
            </thead>
            <tbody>
              {departments.map((d) => (
                <tr key={d.id}>
                  <td className="font-medium text-slate-800">{d.code}</td>
                  <td>{d.name}</td>
                  <td>{d._count.courses}</td>
                  <td>{d._count.classes}</td>
                  <td>{d._count.teachers}</td>
                </tr>
              ))}
              {departments.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-center text-slate-400 py-6">
                    No departments yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <NewDepartmentForm />
      </div>
    </div>
  );
}
