import { prisma } from "@/lib/prisma";
import StatCard from "@/components/StatCard";
import AttendanceBarChart from "@/components/charts/AttendanceBarChart";
import { Users, Presentation, School, BookOpen } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function AdminOverviewPage() {
  const [studentCount, teacherCount, classCount, courseCount, classes] = await Promise.all([
    prisma.student.count(),
    prisma.teacher.count(),
    prisma.class.count(),
    prisma.course.count(),
    prisma.class.findMany({ include: { department: true } }),
  ]);

  const chartData = [];
  for (const c of classes) {
    const records = await prisma.attendance.findMany({
      where: { student: { classId: c.id }, session: { cancelled: false } },
      select: { status: true },
    });
    const total = records.length;
    const present = records.filter((r) => r.status === "PRESENT").length;
    const pct = total === 0 ? 0 : Math.round((present / total) * 10000) / 100;
    chartData.push({ name: `${c.department.code} ${c.semester}${c.section}`, percentage: pct });
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Admin overview</h1>
        <p className="text-sm text-slate-500">Institution-wide snapshot.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Students" value={studentCount} icon={Users} />
        <StatCard label="Teachers" value={teacherCount} icon={Presentation} />
        <StatCard label="Classes" value={classCount} icon={School} />
        <StatCard label="Courses" value={courseCount} icon={BookOpen} />
      </div>

      <div className="card">
        <h2 className="font-semibold text-slate-900 mb-4">Average attendance by class</h2>
        {chartData.length === 0 ? (
          <p className="text-sm text-slate-500">No classes yet.</p>
        ) : (
          <AttendanceBarChart data={chartData} />
        )}
      </div>
    </div>
  );
}
