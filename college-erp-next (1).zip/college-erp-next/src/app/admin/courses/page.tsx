import { prisma } from "@/lib/prisma";
import NewCourseForm from "./NewCourseForm";

export const dynamic = "force-dynamic";

export default async function CoursesPage() {
  const [courses, departments] = await Promise.all([
    prisma.course.findMany({ include: { department: true }, orderBy: { code: "asc" } }),
    prisma.department.findMany({ orderBy: { code: "asc" } }),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Courses</h1>
        <p className="text-sm text-slate-500">Subjects offered by each department.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card overflow-x-auto">
          <table className="table-clean">
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Short</th>
                <th>Department</th>
              </tr>
            </thead>
            <tbody>
              {courses.map((c) => (
                <tr key={c.id}>
                  <td className="font-medium text-slate-800">{c.code}</td>
                  <td>{c.name}</td>
                  <td>{c.shortName}</td>
                  <td>{c.department.code}</td>
                </tr>
              ))}
              {courses.length === 0 && (
                <tr>
                  <td colSpan={4} className="text-center text-slate-400 py-6">
                    No courses yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        {departments.length > 0 ? (
          <NewCourseForm departments={departments} />
        ) : (
          <div className="card text-sm text-slate-500">Add a department first.</div>
        )}
      </div>
    </div>
  );
}
