"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Plus } from "lucide-react";

export default function NewCourseForm({ departments }: { departments: { id: string; code: string; name: string }[] }) {
  const router = useRouter();
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [shortName, setShortName] = useState("");
  const [departmentId, setDepartmentId] = useState(departments[0]?.id ?? "");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const res = await fetch("/api/admin/courses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, name, shortName, departmentId }),
    });
    setSaving(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Could not create course.");
      return;
    }
    setCode("");
    setName("");
    setShortName("");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="card space-y-3">
      <h2 className="font-semibold text-slate-900">Add course</h2>
      <div>
        <label className="label">Department</label>
        <select className="input" value={departmentId} onChange={(e) => setDepartmentId(e.target.value)} required>
          {departments.map((d) => (
            <option key={d.id} value={d.id}>
              {d.code} - {d.name}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="label">Course code</label>
        <input className="input" placeholder="CS701" value={code} onChange={(e) => setCode(e.target.value)} required />
      </div>
      <div>
        <label className="label">Course name</label>
        <input className="input" placeholder="Internet of Things" value={name} onChange={(e) => setName(e.target.value)} required />
      </div>
      <div>
        <label className="label">Short name</label>
        <input className="input" placeholder="IoT" value={shortName} onChange={(e) => setShortName(e.target.value)} required />
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <button className="btn-primary" disabled={saving} type="submit">
        <Plus size={16} /> {saving ? "Adding..." : "Add course"}
      </button>
    </form>
  );
}
