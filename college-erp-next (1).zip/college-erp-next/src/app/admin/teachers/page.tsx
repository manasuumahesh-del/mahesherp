import { prisma } from "@/lib/prisma";
import NewTeacherForm from "./NewTeacherForm";

export const dynamic = "force-dynamic";

export default async function TeachersPage() {
  const [teachers, departments] = await Promise.all([
    prisma.teacher.findMany({
      include: { user: true, department: true, _count: { select: { assigns: true } } },
      orderBy: { employeeId: "asc" },
    }),
    prisma.department.findMany({ orderBy: { code: "asc" } }),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Teachers</h1>
        <p className="text-sm text-slate-500">Faculty accounts and their department.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card overflow-x-auto">
          <table className="table-clean">
            <thead>
              <tr>
                <th>Employee ID</th>
                <th>Name</th>
                <th>Username</th>
                <th>Department</th>
                <th>Classes</th>
              </tr>
            </thead>
            <tbody>
              {teachers.map((t) => (
                <tr key={t.id}>
                  <td className="font-medium text-slate-800">{t.employeeId}</td>
                  <td>{t.user.name}</td>
                  <td className="font-mono text-xs">{t.user.username}</td>
                  <td>{t.department.code}</td>
                  <td>{t._count.assigns}</td>
                </tr>
              ))}
              {teachers.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-center text-slate-400 py-6">
                    No teachers yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        {departments.length > 0 ? (
          <NewTeacherForm departments={departments} />
        ) : (
          <div className="card text-sm text-slate-500">Add a department first.</div>
        )}
      </div>
    </div>
  );
}
