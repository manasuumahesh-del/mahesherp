"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Plus, Copy } from "lucide-react";

export default function NewTeacherForm({ departments }: { departments: { id: string; code: string }[] }) {
  const router = useRouter();
  const [employeeId, setEmployeeId] = useState("");
  const [name, setName] = useState("");
  const [departmentId, setDepartmentId] = useState(departments[0]?.id ?? "");
  const [sex, setSex] = useState("MALE");
  const [dob, setDob] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [credentials, setCredentials] = useState<{ username: string; password: string } | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setCredentials(null);
    const res = await fetch("/api/admin/teachers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ employeeId, name, departmentId, sex, dob, email }),
    });
    const data = await res.json().catch(() => ({}));
    setSaving(false);
    if (!res.ok) {
      setError(data.error || "Could not create teacher.");
      return;
    }
    setCredentials(data.credentials);
    setEmployeeId("");
    setName("");
    setDob("");
    setEmail("");
    router.refresh();
  }

  return (
    <div className="card space-y-3">
      <h2 className="font-semibold text-slate-900">Add teacher</h2>
      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <label className="label">Employee ID</label>
          <input className="input" value={employeeId} onChange={(e) => setEmployeeId(e.target.value)} required />
        </div>
        <div>
          <label className="label">Full name</label>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div>
          <label className="label">Department</label>
          <select className="input" value={departmentId} onChange={(e) => setDepartmentId(e.target.value)} required>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.code}
              </option>
            ))}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Sex</label>
            <select className="input" value={sex} onChange={(e) => setSex(e.target.value)}>
              <option value="MALE">Male</option>
              <option value="FEMALE">Female</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
          <div>
            <label className="label">Date of birth</label>
            <input type="date" className="input" value={dob} onChange={(e) => setDob(e.target.value)} required />
          </div>
        </div>
        <div>
          <label className="label">Email (optional, for notifications)</label>
          <input type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button className="btn-primary" disabled={saving} type="submit">
          <Plus size={16} /> {saving ? "Adding..." : "Add teacher"}
        </button>
      </form>

      {credentials && (
        <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-sm text-emerald-800">
          <p className="font-medium mb-1">Account created - share these once:</p>
          <p>
            Username: <code className="font-mono">{credentials.username}</code>
          </p>
          <p>
            Temporary password: <code className="font-mono">{credentials.password}</code>
          </p>
          <p className="text-xs mt-1 text-emerald-700">They'll be asked to set a new password on first login.</p>
        </div>
      )}
    </div>
  );
}
