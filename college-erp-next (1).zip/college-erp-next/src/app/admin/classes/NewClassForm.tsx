"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Plus } from "lucide-react";

export default function NewClassForm({ departments }: { departments: { id: string; code: string }[] }) {
  const router = useRouter();
  const [departmentId, setDepartmentId] = useState(departments[0]?.id ?? "");
  const [section, setSection] = useState("");
  const [semester, setSemester] = useState(1);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const res = await fetch("/api/admin/classes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ departmentId, section, semester }),
    });
    setSaving(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Could not create class.");
      return;
    }
    setSection("");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="card space-y-3">
      <h2 className="font-semibold text-slate-900">Add class</h2>
      <div>
        <label className="label">Department</label>
        <select className="input" value={departmentId} onChange={(e) => setDepartmentId(e.target.value)} required>
          {departments.map((d) => (
            <option key={d.id} value={d.id}>
              {d.code}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="label">Section</label>
        <input className="input" placeholder="A" value={section} onChange={(e) => setSection(e.target.value)} required />
      </div>
      <div>
        <label className="label">Semester</label>
        <input
          type="number"
          min={1}
          max={8}
          className="input"
          value={semester}
          onChange={(e) => setSemester(Number(e.target.value))}
          required
        />
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <button className="btn-primary" disabled={saving} type="submit">
        <Plus size={16} /> {saving ? "Adding..." : "Add class"}
      </button>
    </form>
  );
}
