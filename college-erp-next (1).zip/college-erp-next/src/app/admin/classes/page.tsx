import { prisma } from "@/lib/prisma";
import NewClassForm from "./NewClassForm";

export const dynamic = "force-dynamic";

export default async function ClassesPage() {
  const [classes, departments] = await Promise.all([
    prisma.class.findMany({
      include: { department: true, _count: { select: { students: true, assigns: true } } },
      orderBy: [{ semester: "asc" }, { section: "asc" }],
    }),
    prisma.department.findMany({ orderBy: { code: "asc" } }),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Classes</h1>
        <p className="text-sm text-slate-500">A class is a department + semester + section, e.g. CSE Sem 7 Section A.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card overflow-x-auto">
          <table className="table-clean">
            <thead>
              <tr>
                <th>Department</th>
                <th>Semester</th>
                <th>Section</th>
                <th>Students</th>
                <th>Courses assigned</th>
              </tr>
            </thead>
            <tbody>
              {classes.map((c) => (
                <tr key={c.id}>
                  <td className="font-medium text-slate-800">{c.department.code}</td>
                  <td>{c.semester}</td>
                  <td>{c.section}</td>
                  <td>{c._count.students}</td>
                  <td>{c._count.assigns}</td>
                </tr>
              ))}
              {classes.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-center text-slate-400 py-6">
                    No classes yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        {departments.length > 0 ? (
          <NewClassForm departments={departments} />
        ) : (
          <div className="card text-sm text-slate-500">Add a department first.</div>
        )}
      </div>
    </div>
  );
}
