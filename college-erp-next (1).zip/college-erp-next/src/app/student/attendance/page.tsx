import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getStudentAttendanceSummary } from "@/lib/attendance";
import clsx from "clsx";

export const dynamic = "force-dynamic";

export default async function StudentAttendancePage() {
  const session = await getServerSession(authOptions);
  const student = await prisma.student.findUniqueOrThrow({ where: { userId: session!.user.id } });
  const summary = await getStudentAttendanceSummary(student.id);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Attendance</h1>
        <p className="text-sm text-slate-500">Attendance percentage across all your enrolled courses.</p>
      </div>

      <div className="card overflow-x-auto">
        <table className="table-clean">
          <thead>
            <tr>
              <th>Course</th>
              <th>Attended</th>
              <th>Total classes</th>
              <th>Percentage</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {summary.map((s) => (
              <tr key={s.courseId}>
                <td className="font-medium text-slate-800">{s.courseName}</td>
                <td>{s.attended}</td>
                <td>{s.total}</td>
                <td className="font-semibold">{s.percentage}%</td>
                <td>
                  <span
                    className={clsx(
                      "badge",
                      s.percentage >= 75 ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"
                    )}
                  >
                    {s.percentage >= 75 ? "Good standing" : `Need ${s.classesToAttendFor75} more`}
                  </span>
                </td>
              </tr>
            ))}
            {summary.length === 0 && (
              <tr>
                <td colSpan={5} className="text-center text-slate-400 py-6">
                  No attendance records yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
