import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import AppShell from "@/components/AppShell";
import { LayoutDashboard, CalendarCheck, NotebookPen, CalendarClock } from "lucide-react";

const navItems = [
  { href: "/student", label: "Overview", icon: LayoutDashboard },
  { href: "/student/attendance", label: "Attendance", icon: CalendarCheck },
  { href: "/student/marks", label: "Marks", icon: NotebookPen },
  { href: "/student/timetable", label: "Timetable", icon: CalendarClock },
];

export default async function StudentLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);

  return (
    <AppShell navItems={navItems} roleLabel="Student" userName={session?.user.name || ""}>
      {children}
    </AppShell>
  );
}
