import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { TEST_LABELS, TEST_NAMES, computeCie } from "@/lib/timeSlots";
import MarksBarChart, { type MarksChartDatum } from "@/components/charts/MarksBarChart";
import { Download } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function StudentMarksPage() {
  const session = await getServerSession(authOptions);
  const student = await prisma.student.findUniqueOrThrow({ where: { userId: session!.user.id } });

  const studentCourses = await prisma.studentCourse.findMany({
    where: { studentId: student.id },
    include: { course: true, marks: true },
  });

  const chartData: MarksChartDatum[] = studentCourses.map((sc) => {
    const row: MarksChartDatum = { name: sc.course.shortName };
    for (const test of TEST_NAMES) {
      const m = sc.marks.find((mk) => mk.test === test);
      row[test] = m?.score ?? 0;
    }
    return row;
  });

  const series = [
    { key: "INTERNAL_1", label: "IA1", color: "#255ceb" },
    { key: "INTERNAL_2", label: "IA2", color: "#60a5fa" },
    { key: "INTERNAL_3", label: "IA3", color: "#93c5fd" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">Marks</h1>
          <p className="text-sm text-slate-500">Your internal assessment and event scores per course.</p>
        </div>
        <a href="/api/export/my-marks" className="btn-secondary">
          <Download size={16} /> Export as Excel
        </a>
      </div>

      <div className="card">
        <h2 className="font-semibold text-slate-900 mb-4">Internal test scores</h2>
        {chartData.length === 0 ? (
          <p className="text-sm text-slate-500">No marks recorded yet.</p>
        ) : (
          <MarksBarChart data={chartData} series={series} />
        )}
      </div>

      {studentCourses.map((sc) => (
        <div key={sc.id} className="card overflow-x-auto">
          <h2 className="font-semibold text-slate-900 mb-3">{sc.course.name}</h2>
          <table className="table-clean">
            <thead>
              <tr>
                {TEST_NAMES.map((t) => (
                  <th key={t}>{TEST_LABELS[t]}</th>
                ))}
                <th>CIE (out of 40)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                {TEST_NAMES.map((t) => {
                  const m = sc.marks.find((mk) => mk.test === t);
                  return (
                    <td key={t} className="font-medium">
                      {m ? `${m.score} / ${m.maxScore}` : "-"}
                    </td>
                  );
                })}
                <td className="font-semibold text-brand-700">{computeCie(sc.marks)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
}
