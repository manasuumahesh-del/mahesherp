import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getStudentAttendanceSummary } from "@/lib/attendance";
import { TEST_LABELS } from "@/lib/timeSlots";
import StatCard from "@/components/StatCard";
import AttendanceBarChart from "@/components/charts/AttendanceBarChart";
import { CalendarCheck, NotebookPen, TrendingDown, Users } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function StudentOverviewPage() {
  const session = await getServerSession(authOptions);
  const student = await prisma.student.findUniqueOrThrow({
    where: { userId: session!.user.id },
    include: { class: { include: { department: true } } },
  });

  const attendance = await getStudentAttendanceSummary(student.id);
  const overallPct =
    attendance.length === 0
      ? 0
      : Math.round((attendance.reduce((s, a) => s + a.percentage, 0) / attendance.length) * 100) / 100;

  const lowCourses = attendance.filter((a) => a.percentage < 75);

  const studentCourses = await prisma.studentCourse.findMany({
    where: { studentId: student.id },
    include: { course: true, marks: true },
  });

  const chartData = attendance.map((a) => ({ name: a.courseShortName, percentage: a.percentage }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Welcome back, {session!.user.name}</h1>
        <p className="text-sm text-slate-500">
          {student.class.department.name} - Semester {student.class.semester} {student.class.section} - USN {student.usn}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Overall attendance" value={`${overallPct}%`} icon={CalendarCheck} tone={overallPct < 75 ? "red" : "green"} />
        <StatCard label="Courses enrolled" value={studentCourses.length} icon={NotebookPen} />
        <StatCard label="Below 75% attendance" value={lowCourses.length} icon={TrendingDown} tone={lowCourses.length > 0 ? "red" : "green"} />
        <StatCard label="Classmates" value={await prisma.student.count({ where: { classId: student.classId } })} icon={Users} />
      </div>

      <div className="card">
        <h2 className="font-semibold text-slate-900 mb-4">Attendance by course</h2>
        {chartData.length === 0 ? (
          <p className="text-sm text-slate-500">No attendance recorded yet.</p>
        ) : (
          <AttendanceBarChart data={chartData} />
        )}
      </div>

      {lowCourses.length > 0 && (
        <div className="card border-red-200 bg-red-50/50">
          <h2 className="font-semibold text-red-700 mb-2">Attendance shortage</h2>
          <ul className="text-sm text-red-700 space-y-1">
            {lowCourses.map((c) => (
              <li key={c.courseId}>
                {c.courseName}: {c.percentage}% - attend the next {c.classesToAttendFor75} class(es) in a row to reach 75%.
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
