import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole, AuthError } from "@/lib/authz";
import { getTeacherBySessionUserId, getOwnedAssign } from "@/lib/teacher";
import { takeAttendanceSchema } from "@/lib/validation";
import { sendEmail, lowAttendanceEmail } from "@/lib/email";

export async function POST(req: NextRequest) {
  try {
    const session = await requireRole("TEACHER");
    const teacher = await getTeacherBySessionUserId(session.user.id);

    const body = await req.json();
    const parsed = takeAttendanceSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message || "Invalid input" }, { status: 400 });
    }
    const { assignId, date, statuses } = parsed.data;

    const assign = await getOwnedAssign(assignId, teacher.id);

    // Make sure every studentId in the payload actually belongs to this class.
    const validStudentIds = new Set(
      (await prisma.student.findMany({ where: { classId: assign.classId }, select: { id: true } })).map((s) => s.id)
    );
    for (const studentId of Object.keys(statuses)) {
      if (!validStudentIds.has(studentId)) {
        return NextResponse.json({ error: "Unknown student in submission" }, { status: 400 });
      }
    }

    const attSession = await prisma.attendanceSession.upsert({
      where: { assignId_date: { assignId: assign.id, date } },
      update: {},
      create: { assignId: assign.id, date },
    });

    await prisma.$transaction(
      Object.entries(statuses).map(([studentId, status]) =>
        prisma.attendance.upsert({
          where: { sessionId_studentId: { sessionId: attSession.id, studentId } },
          update: { status },
          create: { sessionId: attSession.id, studentId, status },
        })
      )
    );

    // Notify students who were marked absent today and have dropped below
    // the 75% attendance requirement for this course. Best-effort, never
    // blocks the response.
    const absentToday = Object.entries(statuses)
      .filter(([, status]) => status === "ABSENT")
      .map(([studentId]) => studentId);

    if (absentToday.length > 0) {
      notifyLowAttendance(absentToday, assign.id, assign.courseId).catch((e) =>
        console.error("[attendance] low-attendance notification failed:", e)
      );
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    console.error(err);
    return NextResponse.json({ error: (err as Error).message || "Something went wrong" }, { status: 500 });
  }
}

async function notifyLowAttendance(studentIds: string[], assignId: string, courseId: string) {
  const course = await prisma.course.findUnique({ where: { id: courseId } });
  if (!course) return;

  for (const studentId of studentIds) {
    const records = await prisma.attendance.findMany({
      where: { studentId, session: { assignId, cancelled: false } },
    });
    const total = records.length;
    const attended = records.filter((r) => r.status === "PRESENT").length;
    if (total === 0) continue;
    const pct = Math.round((attended / total) * 10000) / 100;
    if (pct >= 75) continue;

    const student = await prisma.student.findUnique({ where: { id: studentId }, include: { user: true } });
    if (!student) continue;
    const { subject, html } = lowAttendanceEmail(student.user.name, course.name, pct);
    await sendEmail(student.user.email, subject, html);
  }
}
