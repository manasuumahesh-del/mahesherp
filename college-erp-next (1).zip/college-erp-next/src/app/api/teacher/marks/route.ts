import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole, AuthError } from "@/lib/authz";
import { getTeacherBySessionUserId, getOwnedAssign } from "@/lib/teacher";
import { enterMarksSchema } from "@/lib/validation";
import { ensureEnrollment } from "@/lib/enrollment";
import { maxScoreFor, TEST_LABELS } from "@/lib/timeSlots";
import { sendEmail, marksPublishedEmail } from "@/lib/email";

export async function POST(req: NextRequest) {
  try {
    const session = await requireRole("TEACHER");
    const teacher = await getTeacherBySessionUserId(session.user.id);

    const body = await req.json();
    const parsed = enterMarksSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message || "Invalid input" }, { status: 400 });
    }
    const { assignId, test, scores } = parsed.data;
    const assign = await getOwnedAssign(assignId, teacher.id);
    const max = maxScoreFor(test);

    const validStudentIds = new Set(
      (await prisma.student.findMany({ where: { classId: assign.classId }, select: { id: true } })).map((s) => s.id)
    );

    const notifyList: { email: string | null; name: string; score: number }[] = [];

    for (const [studentId, rawScore] of Object.entries(scores)) {
      if (!validStudentIds.has(studentId)) continue;
      const score = Math.max(0, Math.min(max, rawScore));

      const sc = await ensureEnrollment(studentId, assign.courseId);
      await prisma.marks.update({
        where: { studentCourseId_test: { studentCourseId: sc.id, test } },
        data: { score, maxScore: max },
      });

      const student = await prisma.student.findUnique({ where: { id: studentId }, include: { user: true } });
      if (student) notifyList.push({ email: student.user.email, name: student.user.name, score });
    }

    await prisma.marksClass.upsert({
      where: { assignId_test: { assignId: assign.id, test } },
      update: { published: true },
      create: { assignId: assign.id, test, published: true },
    });

    // Fire-and-forget notification emails; failures are logged, not thrown.
    for (const n of notifyList) {
      const { subject, html } = marksPublishedEmail(n.name, assign.course.name, TEST_LABELS[test], n.score, max);
      sendEmail(n.email, subject, html).catch(() => {});
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    console.error(err);
    return NextResponse.json({ error: (err as Error).message || "Something went wrong" }, { status: 500 });
  }
}
