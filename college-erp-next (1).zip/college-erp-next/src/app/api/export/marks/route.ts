import { NextRequest, NextResponse } from "next/server";
import ExcelJS from "exceljs";
import { prisma } from "@/lib/prisma";
import { requireRole, AuthError } from "@/lib/authz";
import { getTeacherBySessionUserId, getOwnedAssign } from "@/lib/teacher";
import { TEST_NAMES, TEST_LABELS, computeCie } from "@/lib/timeSlots";

export async function GET(req: NextRequest) {
  try {
    const session = await requireRole("TEACHER", "ADMIN");
    const assignId = req.nextUrl.searchParams.get("assignId");
    if (!assignId) return NextResponse.json({ error: "assignId is required" }, { status: 400 });

    let assign;
    if (session.user.role === "TEACHER") {
      const teacher = await getTeacherBySessionUserId(session.user.id);
      assign = await getOwnedAssign(assignId, teacher.id);
    } else {
      assign = await prisma.assign.findUniqueOrThrow({
        where: { id: assignId },
        include: { course: true, class: { include: { department: true } } },
      });
    }

    const students = await prisma.student.findMany({
      where: { classId: assign.classId },
      include: {
        user: true,
        studentCourses: { where: { courseId: assign.courseId }, include: { marks: true } },
      },
      orderBy: { usn: "asc" },
    });

    const workbook = new ExcelJS.Workbook();
    workbook.creator = "College ERP";
    const sheet = workbook.addWorksheet("Marks");

    sheet.columns = [
      { header: "USN", key: "usn", width: 16 },
      { header: "Name", key: "name", width: 26 },
      ...TEST_NAMES.map((t) => ({ header: TEST_LABELS[t], key: t, width: 16 })),
      { header: "CIE (/40)", key: "cie", width: 12 },
    ];
    sheet.getRow(1).font = { bold: true };

    for (const s of students) {
      const marks = s.studentCourses[0]?.marks ?? [];
      const row: Record<string, string | number> = { usn: s.usn, name: s.user.name };
      for (const t of TEST_NAMES) {
        const m = marks.find((mk) => mk.test === t);
        row[t] = m ? m.score : 0;
      }
      row.cie = computeCie(marks);
      sheet.addRow(row);
    }

    const buffer = await workbook.xlsx.writeBuffer();
    const filename = `${assign.course.shortName}-marks.xlsx`;

    return new NextResponse(buffer, {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    console.error(err);
    return NextResponse.json({ error: (err as Error).message || "Something went wrong" }, { status: 500 });
  }
}
