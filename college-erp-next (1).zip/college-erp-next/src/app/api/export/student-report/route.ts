import { NextRequest, NextResponse } from "next/server";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { prisma } from "@/lib/prisma";
import { requireRole, AuthError } from "@/lib/authz";
import { getTeacherBySessionUserId, getOwnedAssign } from "@/lib/teacher";
import { TEST_NAMES, TEST_LABELS, computeCie } from "@/lib/timeSlots";

export async function GET(req: NextRequest) {
  try {
    const session = await requireRole("TEACHER");
    const teacher = await getTeacherBySessionUserId(session.user.id);
    const assignId = req.nextUrl.searchParams.get("assignId");
    const studentId = req.nextUrl.searchParams.get("studentId");
    if (!assignId || !studentId) {
      return NextResponse.json({ error: "assignId and studentId are required" }, { status: 400 });
    }

    const assign = await getOwnedAssign(assignId, teacher.id);
    const student = await prisma.student.findFirstOrThrow({
      where: { id: studentId, classId: assign.classId },
      include: { user: true },
    });

    const studentCourse = await prisma.studentCourse.findUnique({
      where: { studentId_courseId: { studentId: student.id, courseId: assign.courseId } },
      include: { marks: true },
    });
    const attRecords = await prisma.attendance.findMany({
      where: { studentId: student.id, session: { assignId: assign.id, cancelled: false } },
    });
    const total = attRecords.length;
    const attended = attRecords.filter((r) => r.status === "PRESENT").length;
    const pct = total === 0 ? 0 : Math.round((attended / total) * 10000) / 100;

    const pdf = await PDFDocument.create();
    const page = pdf.addPage([595.28, 841.89]); // A4
    const font = await pdf.embedFont(StandardFonts.Helvetica);
    const bold = await pdf.embedFont(StandardFonts.HelveticaBold);

    let y = 780;
    const drawText = (text: string, opts: { x?: number; size?: number; f?: typeof font; color?: ReturnType<typeof rgb> } = {}) => {
      page.drawText(text, {
        x: opts.x ?? 50,
        y,
        size: opts.size ?? 11,
        font: opts.f ?? font,
        color: opts.color ?? rgb(0.1, 0.1, 0.1),
      });
    };

    drawText("College ERP - Student Report", { size: 18, f: bold });
    y -= 30;
    drawText(`Name: ${student.user.name}`, { f: bold });
    y -= 18;
    drawText(`USN: ${student.usn}`);
    y -= 18;
    drawText(`Course: ${assign.course.name} (${assign.course.shortName})`);
    y -= 18;
    drawText(`Class: ${assign.class.department.code} Sem ${assign.class.semester} ${assign.class.section}`);
    y -= 30;

    drawText("Attendance", { size: 14, f: bold });
    y -= 20;
    drawText(`Attended ${attended} of ${total} classes (${pct}%)`, {
      color: pct < 75 ? rgb(0.8, 0.1, 0.1) : rgb(0.05, 0.5, 0.2),
    });
    y -= 30;

    drawText("Marks", { size: 14, f: bold });
    y -= 20;
    const marks = studentCourse?.marks ?? [];
    for (const t of TEST_NAMES) {
      const m = marks.find((mk) => mk.test === t);
      drawText(`${TEST_LABELS[t]}: ${m ? `${m.score} / ${m.maxScore}` : "Not entered"}`);
      y -= 16;
    }
    y -= 10;
    drawText(`CIE (out of 40): ${computeCie(marks)}`, { f: bold });

    y -= 40;
    drawText(`Generated ${new Date().toLocaleDateString()}`, { size: 9, color: rgb(0.5, 0.5, 0.5) });

    const bytes = await pdf.save();
    return new NextResponse(Buffer.from(bytes), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${student.usn}-report.pdf"`,
      },
    });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    console.error(err);
    return NextResponse.json({ error: (err as Error).message || "Something went wrong" }, { status: 500 });
  }
}
