import { NextResponse } from "next/server";
import ExcelJS from "exceljs";
import { prisma } from "@/lib/prisma";
import { requireRole, AuthError } from "@/lib/authz";
import { TEST_NAMES, TEST_LABELS, computeCie } from "@/lib/timeSlots";

export async function GET() {
  try {
    const session = await requireRole("STUDENT");
    const student = await prisma.student.findUniqueOrThrow({ where: { userId: session.user.id }, include: { user: true } });

    const studentCourses = await prisma.studentCourse.findMany({
      where: { studentId: student.id },
      include: { course: true, marks: true },
    });

    const workbook = new ExcelJS.Workbook();
    workbook.creator = "College ERP";
    const sheet = workbook.addWorksheet("My Marks");
    sheet.columns = [
      { header: "Course", key: "course", width: 28 },
      ...TEST_NAMES.map((t) => ({ header: TEST_LABELS[t], key: t, width: 16 })),
      { header: "CIE (/40)", key: "cie", width: 12 },
    ];
    sheet.getRow(1).font = { bold: true };

    for (const sc of studentCourses) {
      const row: Record<string, string | number> = { course: sc.course.name };
      for (const t of TEST_NAMES) {
        const m = sc.marks.find((mk) => mk.test === t);
        row[t] = m ? m.score : 0;
      }
      row.cie = computeCie(sc.marks);
      sheet.addRow(row);
    }

    const buffer = await workbook.xlsx.writeBuffer();
    return new NextResponse(buffer, {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="my-marks.xlsx"`,
      },
    });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    console.error(err);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
