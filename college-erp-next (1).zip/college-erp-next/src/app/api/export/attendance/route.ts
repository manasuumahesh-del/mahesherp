import { NextRequest, NextResponse } from "next/server";
import ExcelJS from "exceljs";
import { prisma } from "@/lib/prisma";
import { requireRole, AuthError } from "@/lib/authz";
import { getTeacherBySessionUserId, getOwnedAssign } from "@/lib/teacher";

export async function GET(req: NextRequest) {
  try {
    const session = await requireRole("TEACHER", "ADMIN");
    const assignId = req.nextUrl.searchParams.get("assignId");
    if (!assignId) return NextResponse.json({ error: "assignId is required" }, { status: 400 });

    let assign;
    if (session.user.role === "TEACHER") {
      const teacher = await getTeacherBySessionUserId(session.user.id);
      assign = await getOwnedAssign(assignId, teacher.id);
    } else {
      assign = await prisma.assign.findUniqueOrThrow({
        where: { id: assignId },
        include: { course: true, class: { include: { department: true } } },
      });
    }

    const students = await prisma.student.findMany({
      where: { classId: assign.classId },
      include: { user: true },
      orderBy: { usn: "asc" },
    });

    const rows = [];
    for (const s of students) {
      const records = await prisma.attendance.findMany({
        where: { studentId: s.id, session: { assignId: assign.id, cancelled: false } },
      });
      const total = records.length;
      const attended = records.filter((r) => r.status === "PRESENT").length;
      const pct = total === 0 ? 0 : Math.round((attended / total) * 10000) / 100;
      rows.push({ usn: s.usn, name: s.user.name, attended, total, pct });
    }

    const workbook = new ExcelJS.Workbook();
    workbook.creator = "College ERP";
    const sheet = workbook.addWorksheet("Attendance");
    sheet.columns = [
      { header: "USN", key: "usn", width: 16 },
      { header: "Name", key: "name", width: 26 },
      { header: "Classes attended", key: "attended", width: 18 },
      { header: "Total classes", key: "total", width: 16 },
      { header: "Percentage", key: "pct", width: 14 },
    ];
    sheet.getRow(1).font = { bold: true };
    for (const r of rows) {
      const row = sheet.addRow(r);
      if (r.pct < 75) {
        row.getCell("pct").font = { color: { argb: "FFDC2626" }, bold: true };
      }
    }

    const buffer = await workbook.xlsx.writeBuffer();
    const filename = `${assign.course.shortName}-attendance.xlsx`;

    return new NextResponse(buffer, {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    console.error(err);
    return NextResponse.json({ error: (err as Error).message || "Something went wrong" }, { status: 500 });
  }
}
