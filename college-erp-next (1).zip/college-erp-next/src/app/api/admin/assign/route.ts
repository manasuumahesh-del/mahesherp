import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole, AuthError } from "@/lib/authz";
import { createAssignSchema } from "@/lib/validation";
import { ensureEnrollments, ensureMarksClasses } from "@/lib/enrollment";

export async function POST(req: NextRequest) {
  try {
    await requireRole("ADMIN");
    const body = await req.json();
    const parsed = createAssignSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message || "Invalid input" }, { status: 400 });
    }
    const assign = await prisma.assign.create({ data: parsed.data });
    await ensureEnrollments(parsed.data.classId, parsed.data.courseId);
    await ensureMarksClasses(assign.id);
    return NextResponse.json({ ok: true, assign });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    if ((err as any)?.code === "P2002") {
      return NextResponse.json({ error: "This teacher is already assigned to this course for this class" }, { status: 409 });
    }
    console.error(err);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
