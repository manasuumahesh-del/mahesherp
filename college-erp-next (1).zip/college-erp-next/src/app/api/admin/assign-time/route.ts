import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole, AuthError } from "@/lib/authz";
import { createAssignTimeSchema } from "@/lib/validation";

export async function POST(req: NextRequest) {
  try {
    await requireRole("ADMIN");
    const body = await req.json();
    const parsed = createAssignTimeSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message || "Invalid input" }, { status: 400 });
    }
    const { assignId, day, period } = parsed.data;

    const assign = await prisma.assign.findUniqueOrThrow({ where: { id: assignId } });

    // Guard against double-booking: the same class already has a course in
    // this slot, or the same teacher is already teaching elsewhere in this slot.
    const clash = await prisma.assignTime.findFirst({
      where: {
        day,
        period,
        assign: {
          OR: [{ classId: assign.classId }, { teacherId: assign.teacherId }],
        },
      },
      include: { assign: { include: { course: true, class: true } } },
    });
    if (clash) {
      const isClassClash = clash.assign.classId === assign.classId;
      return NextResponse.json(
        {
          error: isClassClash
            ? `This class already has ${clash.assign.course.shortName} at this time.`
            : `This teacher is already teaching another class at this time.`,
        },
        { status: 409 }
      );
    }

    const assignTime = await prisma.assignTime.create({ data: { assignId, day, period } });
    return NextResponse.json({ ok: true, assignTime });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    if ((err as any)?.code === "P2002") {
      return NextResponse.json({ error: "This slot is already scheduled for this assignment" }, { status: 409 });
    }
    console.error(err);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
