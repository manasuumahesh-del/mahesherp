import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole, AuthError } from "@/lib/authz";
import { createTeacherSchema } from "@/lib/validation";
import { generateDefaultPassword, hashPassword, slugUsername } from "@/lib/passwords";

export async function POST(req: NextRequest) {
  try {
    await requireRole("ADMIN");
    const body = await req.json();
    const parsed = createTeacherSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message || "Invalid input" }, { status: 400 });
    }
    const { employeeId, name, departmentId, sex, dob, email } = parsed.data;

    const username = slugUsername(name, employeeId);
    const password = generateDefaultPassword();
    const passwordHash = await hashPassword(password);

    const result = await prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: { username, passwordHash, name, email: email || null, role: "TEACHER", mustChangePassword: true },
      });
      const teacher = await tx.teacher.create({
        data: { employeeId, userId: user.id, departmentId, sex, dob },
      });
      return { user, teacher };
    });

    return NextResponse.json({
      ok: true,
      teacher: result.teacher,
      credentials: { username, password },
    });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    if ((err as any)?.code === "P2002") {
      return NextResponse.json({ error: "A teacher with this employee ID (or generated username) already exists" }, { status: 409 });
    }
    console.error(err);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
