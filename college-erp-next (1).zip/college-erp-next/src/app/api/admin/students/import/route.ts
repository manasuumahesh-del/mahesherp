import { NextRequest, NextResponse } from "next/server";
import { parse } from "csv-parse/sync";
import { prisma } from "@/lib/prisma";
import { requireRole, AuthError } from "@/lib/authz";
import { csvStudentRowSchema } from "@/lib/validation";
import { generateDefaultPassword, hashPassword, slugUsername } from "@/lib/passwords";
import { ensureEnrollmentsForNewStudent } from "@/lib/enrollment";

type RowResult = { row: number; usn?: string; status: "created" | "skipped" | "error"; message?: string };

export async function POST(req: NextRequest) {
  try {
    await requireRole("ADMIN");

    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }
    const text = await file.text();

    let records: Record<string, string>[];
    try {
      records = parse(text, { columns: true, skip_empty_lines: true, trim: true });
    } catch (e) {
      return NextResponse.json({ error: "Could not parse CSV. Check the file format." }, { status: 400 });
    }

    if (records.length > 1000) {
      return NextResponse.json({ error: "CSV has too many rows (max 1000 per import)." }, { status: 400 });
    }

    const results: RowResult[] = [];
    const createdCredentials: { usn: string; username: string; password: string }[] = [];

    for (let i = 0; i < records.length; i++) {
      const rowNum = i + 2; // account for header row, 1-indexed
      const raw = records[i];
      const parsed = csvStudentRowSchema.safeParse(raw);
      if (!parsed.success) {
        results.push({ row: rowNum, status: "error", message: parsed.error.errors[0]?.message || "Invalid row" });
        continue;
      }
      const { usn, name, section, semester, departmentCode, sex, dob, email } = parsed.data;

      try {
        const existing = await prisma.student.findUnique({ where: { usn } });
        if (existing) {
          results.push({ row: rowNum, usn, status: "skipped", message: "USN already exists" });
          continue;
        }

        const department = await prisma.department.findUnique({ where: { code: departmentCode.toUpperCase() } });
        if (!department) {
          results.push({ row: rowNum, usn, status: "error", message: `Unknown department code: ${departmentCode}` });
          continue;
        }

        const klass = await prisma.class.findUnique({
          where: { departmentId_section_semester: { departmentId: department.id, section, semester } },
        });
        if (!klass) {
          results.push({
            row: rowNum,
            usn,
            status: "error",
            message: `No class found for ${departmentCode} sem ${semester} section ${section}. Create it first.`,
          });
          continue;
        }

        const dobDate = new Date(dob);
        if (isNaN(dobDate.getTime())) {
          results.push({ row: rowNum, usn, status: "error", message: "Invalid date of birth" });
          continue;
        }

        const username = slugUsername(name, usn.slice(-3));
        const password = generateDefaultPassword();
        const passwordHash = await hashPassword(password);

        const student = await prisma.$transaction(async (tx) => {
          const user = await tx.user.create({
            data: { username, passwordHash, name, email: email || null, role: "STUDENT", mustChangePassword: true },
          });
          return tx.student.create({ data: { usn, userId: user.id, classId: klass.id, sex, dob: dobDate } });
        });
        await ensureEnrollmentsForNewStudent(student.id, klass.id);

        results.push({ row: rowNum, usn, status: "created" });
        createdCredentials.push({ usn, username, password });
      } catch (e) {
        results.push({ row: rowNum, usn, status: "error", message: "Unexpected error creating this row" });
      }
    }

    const summary = {
      total: records.length,
      created: results.filter((r) => r.status === "created").length,
      skipped: results.filter((r) => r.status === "skipped").length,
      errors: results.filter((r) => r.status === "error").length,
    };

    return NextResponse.json({ ok: true, summary, results, credentials: createdCredentials });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    console.error(err);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
