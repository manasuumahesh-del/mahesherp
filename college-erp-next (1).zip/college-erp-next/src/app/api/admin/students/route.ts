import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole, AuthError } from "@/lib/authz";
import { createStudentSchema } from "@/lib/validation";
import { generateDefaultPassword, hashPassword, slugUsername } from "@/lib/passwords";
import { ensureEnrollmentsForNewStudent } from "@/lib/enrollment";

export async function POST(req: NextRequest) {
  try {
    await requireRole("ADMIN");
    const body = await req.json();
    const parsed = createStudentSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message || "Invalid input" }, { status: 400 });
    }
    const { usn, name, classId, sex, dob, email } = parsed.data;

    const username = slugUsername(name, usn.slice(-3));
    const password = generateDefaultPassword();
    const passwordHash = await hashPassword(password);

    const student = await prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: { username, passwordHash, name, email: email || null, role: "STUDENT", mustChangePassword: true },
      });
      return tx.student.create({ data: { usn, userId: user.id, classId, sex, dob } });
    });

    await ensureEnrollmentsForNewStudent(student.id, classId);

    return NextResponse.json({ ok: true, student, credentials: { username, password } });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    if ((err as any)?.code === "P2002") {
      return NextResponse.json({ error: "A student with this USN (or generated username) already exists" }, { status: 409 });
    }
    console.error(err);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
